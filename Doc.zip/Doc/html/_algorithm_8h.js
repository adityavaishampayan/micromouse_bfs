var _algorithm_8h =
[
    [ "Algorithm", "classfp_1_1_algorithm.html", "classfp_1_1_algorithm" ],
    [ "Actions", "_algorithm_8h.html#a4aaa1db5eed06b8929824743fe87bd26", [
      [ "Forward", "_algorithm_8h.html#a4aaa1db5eed06b8929824743fe87bd26a3c9d6040913046ba5796a019b772b542", null ],
      [ "Left", "_algorithm_8h.html#a4aaa1db5eed06b8929824743fe87bd26ae63bc091b7b61ce3e745c831689ac81b", null ],
      [ "Right", "_algorithm_8h.html#a4aaa1db5eed06b8929824743fe87bd26adf4acbed16a58764d9213b3ace350d19", null ],
      [ "Backward", "_algorithm_8h.html#a4aaa1db5eed06b8929824743fe87bd26a21d42ff40e3099e93597947737c044d1", null ]
    ] ]
];