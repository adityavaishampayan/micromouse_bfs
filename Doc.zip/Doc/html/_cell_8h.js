var _cell_8h =
[
    [ "Cell", "structfp_1_1_cell.html", "structfp_1_1_cell" ],
    [ "Cells", "_cell_8h.html#ad6c04f1bc858b498621ff1f622fd52b5", [
      [ "NotConnected", "_cell_8h.html#ad6c04f1bc858b498621ff1f622fd52b5a549d2407a4665581b53460dc7504bb7a", null ],
      [ "Connected", "_cell_8h.html#ad6c04f1bc858b498621ff1f622fd52b5a124ec2fae13594973ac63109116ed08d", null ]
    ] ]
];