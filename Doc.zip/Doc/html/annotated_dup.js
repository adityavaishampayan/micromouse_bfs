var annotated_dup =
[
    [ "fp", "namespacefp.html", "namespacefp" ],
    [ "API", "class_a_p_i.html", null ]
];