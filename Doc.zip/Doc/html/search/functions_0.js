var searchData=
[
  ['ackreset',['ackReset',['../class_a_p_i.html#a3e6a76df2da89bd7f7fc72a96e0a9094',1,'API']]],
  ['algorithm',['Algorithm',['../classfp_1_1_algorithm.html#a4625d4166684857ccd68430e0c585831',1,'fp::Algorithm']]]
];
