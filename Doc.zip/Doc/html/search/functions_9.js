var searchData=
[
  ['scansurroundings',['ScanSurroundings',['../classfp_1_1_land_based_robot.html#a66330720cad4c388b9430491211b92db',1,'fp::LandBasedRobot']]],
  ['setcolor',['setColor',['../class_a_p_i.html#aee5aaa673b406ddaab3310fcb3a51d83',1,'API']]],
  ['settext',['setText',['../class_a_p_i.html#a25a489520b0b69b7a0b1870cf350f654',1,'API']]],
  ['setwall',['setWall',['../class_a_p_i.html#a9b0b04cf1cfc62ae6f5eef1ac1729eb2',1,'API::setWall()'],['../classfp_1_1_maze.html#a0669475e6bb5ad94a0f87abb5bbb8b74',1,'fp::Maze::setWall()']]],
  ['speedup',['SpeedUp',['../classfp_1_1_land_based_wheeled.html#ae1359c2a9e442c6a2a5845c15617cf75',1,'fp::LandBasedWheeled']]]
];
